# On Your Door — Virtual Store

Ecommerce website for **On Your Door** (Sanghar, Sindh) — bags, luggage, leather jackets & watches, built with plain HTML, CSS and JavaScript so it deploys straight to GitHub Pages, no build step needed.

## Before you publish — 3 things to update

1. **WhatsApp number** — open `script.js`, first line, replace:
   ```js
   const WHATSAPP_NUMBER = "923000000000";
   ```
   with your real number in international format, digits only (e.g. `923001234567` for `+92 300 1234567`).

2. **Product photos** — right now products show an emoji icon instead of a real photo. To add real photos:
   - Put your product images in the `images/` folder (e.g. `images/jacket-1.jpg`).
   - Open `admin.html` in your browser → unlock with the passcode below → edit each product → paste the image path (e.g. `images/jacket-1.jpg`) into **Image URL**.
   - Or edit the `img: ""` field directly for each product inside `script.js` → `DEFAULT_PRODUCTS`.

3. **Admin passcode** — open `admin.html`, find this line near the bottom and change it:
   ```js
   const ADMIN_PASSCODE = "onyourdoor786";
   ```
   Note: this is a simple front-end lock, fine for keeping casual visitors out of the panel — it is **not** real security since anyone can view the page source. Don't use it to protect anything sensitive.

## How the product system works

- All products live in the browser's `localStorage`, seeded from `DEFAULT_PRODUCTS` in `script.js` the first time someone visits.
- `admin.html` lets you add, edit, or delete products — changes save to `localStorage` on **that browser**.
- Because `localStorage` is per-browser, product edits you make on your own laptop/phone won't automatically show up for every visitor. For a shop that only you manage, this is fine as long as you always edit products from the same browser/device before sharing the link. If you outgrow this later, the next step is a small backend (e.g. Firebase Firestore) so every visitor sees the same catalog — happy to help with that when you're ready.

## Deploying to GitHub Pages

1. Create a new GitHub repository (e.g. `onyourdoor-store`).
2. Push these files (`index.html`, `admin.html`, `style.css`, `script.js`, `images/`) to the repo root.
3. On GitHub: **Settings → Pages → Source → Deploy from branch → main / (root)** → Save.
4. Your site will be live at `https://<your-username>.github.io/onyourdoor-store/` within a minute or two.
5. If you later point your own domain (`onyourdoor.online`) at it, add a `CNAME` file with the domain name, and set that up in your domain's DNS settings.

## What's included

- Responsive storefront with hero, categories, product grid, search and filters
- Shopping cart (localStorage-based, persists between visits)
- One-tap **checkout via WhatsApp** — builds an order message with items, quantities and total automatically
- Product quick-view modal
- Admin panel (`admin.html`) to add/edit/remove products without touching code
- Mobile-friendly navigation and cart drawer

## File structure

```
onyourdoor/
├── index.html      → main storefront
├── admin.html       → product management panel
├── style.css        → all styling
├── script.js        → cart, product rendering, WhatsApp checkout
├── images/
│   └── logo.jpg     → your store logo
└── README.md
```
